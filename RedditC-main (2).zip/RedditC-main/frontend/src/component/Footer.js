import React from "react";
import "./footer.css";
function Footer() {
  return <div className="footer">This is footer</div>;
}

export default Footer;
